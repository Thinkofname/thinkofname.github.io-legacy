package think.ld26.screens;

import java.util.Map.Entry;

import think.ld26.LudumDare;
import think.ld26.entity.Player;
import think.ld26.items.Item;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

public class Inventory extends Screen {

    private Player player;
    private ShapeRenderer renderer = new ShapeRenderer();
    private SpriteBatch batch = new SpriteBatch();
    private Camera camera = new OrthographicCamera(240, 160);
    private int selectedItem = 0;
    private int delay = 15;
    private Sound click;

    public Inventory(Player player) {
        this.player = player;
        click = Gdx.audio.newSound(Gdx.files.internal("data/sounds/select.wav"));
        click.play();
    }

    @Override
    public boolean render() {
        delay--;
        if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.UP)) {
            selectedItem--;
            delay = 15;
            click.play();
        } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            selectedItem++;
            delay = 15;
            click.play();
        } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.Z)) {
            int i = 0;
            for (Entry<String, Integer> e : player.inventory.entrySet()) {
                if (i == selectedItem) {
                    player.inventory.remove(e.getKey());
                    break;
                }
                i++;
            }
            delay = 15;
        } else if (Gdx.input.isKeyPressed(Input.Keys.X)) {
            Menu menu = new Menu(player);
            menu.selectedItem = 1;
            LudumDare.display(menu);
            return false;
        }
        if (selectedItem < 0) {
            selectedItem = player.inventory.size() + 1 - selectedItem;
        }
        if (player.inventory.size() > 0) { 
            selectedItem %= player.inventory.size();
        } else {
            selectedItem = 0;
        }
        renderer.setProjectionMatrix(camera.combined);
        renderer.begin(ShapeType.Filled);
        renderer.identity();
        renderer.translate(0, 0, 0);
        renderer.setColor(Color.WHITE);
        renderer.rect(-100, -70, 200, 140);
        renderer.setColor(Color.YELLOW);
        renderer.translate(-99, 43- selectedItem * LudumDare.font.getLineHeight(), 0);
        renderer.triangle(8, 0, 0, 10, 0, -10);
        renderer.end();
        renderer.begin(ShapeType.Line);
        renderer.identity();
        renderer.translate(0, 0, 0);
        renderer.setColor(Color.BLACK);
        renderer.rect(-100, -70, 200, 140);
        renderer.end();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        LudumDare.font.setColor(Color.BLACK);
        LudumDare.font.draw(batch, "Bag", -90, 70);
        LudumDare.font.setColor(Color.GREEN);
        LudumDare.font.draw(batch, "Bag", -91, 71);
        int i = 0;
        for (Entry<String, Integer> e : player.inventory.entrySet()) {
            LudumDare.font.setColor(i == selectedItem ? Color.ORANGE : Color.CYAN);
            Item item = Item.getItem(e.getKey());
            LudumDare.font.draw(batch, item.getDisplayName() + " x" + e.getValue(), -91, 50 - i * LudumDare.font.getLineHeight());
            i++;
        }
        LudumDare.font.setColor(Color.BLACK);
        LudumDare.font.draw(batch, "Press Z to drop", -90, -50);
        LudumDare.font.setColor(Color.GREEN);
        LudumDare.font.draw(batch, "Press Z to drop", -91, -49);
        batch.end();
        return false;
    }

    @Override
    public void dispose() {
        renderer.dispose();
        batch.dispose();
        click.dispose();
    }

}
