package think.ld26.screens;

import think.ld26.LudumDare;
import think.ld26.entity.Player;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

public class Menu extends Screen {

    private Player player;
    private ShapeRenderer renderer = new ShapeRenderer();
    private SpriteBatch batch = new SpriteBatch();
    private Camera camera = new OrthographicCamera(240, 160);
    public int selectedItem = 0;
    private final static String[] items = new String[] { "Beast", "Bag", "Close" };
    
    private int delay = 15;
    
    private Sound click;

    public Menu(Player player) {
        this.player = player;
        click = Gdx.audio.newSound(Gdx.files.internal("data/sounds/select.wav"));
        click.play();
    }

    @Override
    public boolean render() {
        delay--;
        if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.UP)) {
            selectedItem--;
            delay = 15;
            click.play();
        } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            selectedItem++;
            delay = 15;
            click.play();
        } else if (Gdx.input.isKeyPressed(Input.Keys.Z)) {
            switch(selectedItem) {
            case 0: //Beasts
                break;
            case 1: //Bag
                LudumDare.display(new Inventory(player));
                return false;
            case 2: //Close
                return true;
            }
        } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.X)) {
            return true;
        }
        if (selectedItem < 0) {
            selectedItem = items.length + 1 - selectedItem;
        }
        selectedItem %= items.length;
        renderer.setProjectionMatrix(camera.combined);
        renderer.begin(ShapeType.Filled);
        renderer.identity();
        renderer.translate(36, -80, 0);
        renderer.setColor(Color.WHITE);
        renderer.rect(0, 0, 84, 160);
        renderer.setColor(Color.YELLOW);
        renderer.translate(0, 135 - selectedItem * LudumDare.font.getLineHeight(), 0);
        renderer.triangle(8, 0, 0, 10, 0, -10);
        renderer.end();
        renderer.begin(ShapeType.Line);
        renderer.identity();
        renderer.translate(36, -80, 0);
        renderer.setColor(Color.BLACK);
        renderer.rect(0, 0, 84, 160);
        renderer.end();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        LudumDare.font.setColor(Color.BLACK);
        LudumDare.font.draw(batch, "Menu", 51, 74);
        LudumDare.font.setColor(Color.GREEN);
        LudumDare.font.draw(batch, "Menu", 50, 75);
        for (int i = 0; i < items.length; i++) {
            LudumDare.font.setColor(i == selectedItem ? Color.ORANGE : Color.BLACK);
            LudumDare.font.draw(batch, items[i], 50, 60 - i * LudumDare.font.getLineHeight());
        }
        batch.end();
        return false;
    }

    @Override
    public void dispose() {
        renderer.dispose();
        batch.dispose();
        click.dispose();
    }

}
