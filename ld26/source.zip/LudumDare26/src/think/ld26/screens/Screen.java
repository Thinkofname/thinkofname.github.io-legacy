package think.ld26.screens;

public abstract class Screen {
    
    public abstract boolean render();
    
    public abstract void dispose();
}
