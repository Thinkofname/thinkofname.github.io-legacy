package think.ld26.screens;

import java.util.Random;
import java.util.Map.Entry;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

import think.ld26.LudumDare;
import think.ld26.combat.Beast;
import think.ld26.entity.Player;
import think.ld26.items.Item;

public class Battle extends Screen {

    private Player player;
    private Music music;
    private static Texture texture;
    private static Sprite background;
    private ShapeRenderer renderer = new ShapeRenderer();
    private SpriteBatch batch = new SpriteBatch();
    private Camera camera = new OrthographicCamera(240, 160);
    private Beast target;
    private Sound click;

    private int currentMenuItem = 0;
    private int menu = 0;

    private MessageBox messageBox = null;
    private int delay = 15;

    private static boolean firstBattle = true;

    public Battle(Player player, Beast target) {
        this.player = player;
        this.target = target;
        click = Gdx.audio.newSound(Gdx.files.internal("data/sounds/select.wav"));
        music = Gdx.audio.newMusic(Gdx.files.internal("data/sounds/battletheme.ogg"));
        music.setLooping(true);
        music.setVolume(0.5f);
        music.play();
        if (texture == null) {
            texture = new Texture(Gdx.files.internal("data/sprites/battleback.png"));
            background = new Sprite(texture, 0, 0, 240, 160);
        }
    }

    @Override
    public boolean render() {
        delay--;
        if (firstBattle) {
            firstBattle = false;
            messageBox = new MessageBox("These beasts are just scared. I don't want to hurt them, lets try and get out these fights with minimum damage done to both of us. Just enough to let us run away");
        }

        if (messageBox == null) {
            if (menu > 60) {
                if (menu == 69) {
                    messageBox = new MessageBox(target.doAbillity(player.beast, new Random().nextInt(4)));
                    if (target.getHealth() <= 0) {
                        menu = 70;
                    } else if (player.beast.getHealth() <= 0) {
                        menu = 71;
                    } else {
                        menu = 0;
                    }
                } else if (menu == 70) {
                    player.beast.bravery += 10;
                    if (player.beast.bravery < 0)
                        player.beast.bravery = 2;
                    LudumDare.display(new MessageBox("You killed `" + target.getName()));
                    return false;
                } else if (menu == 700) {
                    player.beast.bravery += 10;
                    if (player.beast.bravery < 0)
                        player.beast.bravery = 2;
                    return true;
                }else if (menu == 71) {
                    LudumDare.display(new MessageBox("Your `" + player.beast.getName() + "| was slain"));
                    menu = 72;
                } else if (menu == 72) {
                    LudumDare.display(new GameOver(player, false));
                    return false;
                } else if (menu == 80) {
                    double chance = 0.5;
                    if (target.bravery < player.beast.bravery) {
                        chance += 0.1;
                        chance += Math.abs(Math.abs(target.bravery - player.beast.bravery) / player.beast.bravery) / 2;
                    } else {
                        chance -= 0.2;
                    }
                    if (target.health < player.beast.health) {
                        chance += 0.05;
                        chance += Math.abs(Math.abs(target.health - player.beast.health) / player.beast.health) / 2;
                    } else {
                        chance -= 0.2;
                    }
                    if (new Random().nextDouble() < chance) {
                        LudumDare.display(new MessageBox("You escaped!"));
                        return false;
                    } else {
                        messageBox = new MessageBox("You failed to get away");
                        menu = 69;
                    }
                }
            } else {
                int numItems = 3;
                switch (menu) {
                case 0:
                    numItems = 3;
                    break;
                case 1:
                    numItems = 4;
                    break;
                case 40:
                    numItems = player.inventory.size();
                    break;
                }
                if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
                    currentMenuItem += menu != 40 ? 2 : 1;
                    delay = 15;
                    click.play();
                } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.UP)) {
                    currentMenuItem -= menu != 40 ? 2 : 1;
                    delay = 15;
                    click.play();
                } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
                    currentMenuItem -= 1;
                    delay = 15;
                    click.play();
                } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
                    currentMenuItem += 1;
                    delay = 15;
                    click.play();
                } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.Z)) {
                    delay = 15;
                    click.play();
                    switch (menu) {
                    case 0:
                        if (currentMenuItem == 0) {
                            menu = 1;
                            currentMenuItem = 0;
                        } else if (currentMenuItem == 2) {
                            messageBox = new MessageBox("You try to escape");
                            currentMenuItem = 0;
                            menu = 80;
                        } else if (currentMenuItem == 1) {
                            if (player.inventory.size() > 0) {
                                currentMenuItem = 0;
                                menu = 40;
                            }
                        }
                        break;
                    case 1:
                        messageBox = new MessageBox(player.beast.doAbillity(target, currentMenuItem));
                        menu = 69;
                        currentMenuItem = 0;
                        break;
                    case 40:
                        int i = 0;
                        for (Entry<String, Integer> e : player.inventory.entrySet()) {
                            if (i == currentMenuItem) {
                                int count = player.inventory.get(e.getKey());
                                count--;
                                if (count <= 0)
                                    player.inventory.remove(e.getKey());
                                else
                                    player.inventory.put(e.getKey(), count);
                                String message = Item.getItem(e.getKey()).use(player.beast, target);
                                if (message.contains("caught")) {
                                    player.beast = target;
                                    target = new Clone(target.getName());
                                    messageBox = new MessageBox(message);
                                    menu = 700;
                                    currentMenuItem = 0;
                                    break;
                                }
                                messageBox = new MessageBox(message);
                                menu = 69;
                                currentMenuItem = 0;
                                break;
                            }
                            i++;
                        }
                        delay = 15;
                        break;
                    }
                } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.X)) {
                    delay = 15;
                    switch (menu) {
                    case 1:
                        menu = 0;
                        currentMenuItem = 0;
                        break;
                    case 40:
                        menu = 0;
                        currentMenuItem = 0;
                        break;
                    }
                }
                if (currentMenuItem < 0) {
                    currentMenuItem = numItems + 1 - currentMenuItem;
                }
                currentMenuItem %= numItems;
            }
        }

        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        background.setPosition(-120, -80);
        background.draw(batch);
        BitmapFont font = LudumDare.font;
        
        if (menu == 40) {
            batch.end();
            renderer.setProjectionMatrix(camera.combined);
            renderer.begin(ShapeType.Filled);
            renderer.identity();
            renderer.translate(0, 0, 0);
            renderer.setColor(Color.WHITE);
            renderer.rect(-100, -70, 200, 140);
            renderer.setColor(Color.YELLOW);
            renderer.translate(-99, 43- currentMenuItem * LudumDare.font.getLineHeight(), 0);
            renderer.triangle(8, 0, 0, 10, 0, -10);
            renderer.end();
            renderer.begin(ShapeType.Line);
            renderer.identity();
            renderer.translate(0, 0, 0);
            renderer.setColor(Color.BLACK);
            renderer.rect(-100, -70, 200, 140);
            renderer.end();
            batch.setProjectionMatrix(camera.combined);
            batch.begin();
            LudumDare.font.setColor(Color.BLACK);
            LudumDare.font.draw(batch, "Bag", -90, 70);
            LudumDare.font.setColor(Color.GREEN);
            LudumDare.font.draw(batch, "Bag", -91, 71);
            int i = 0;
            for (Entry<String, Integer> e : player.inventory.entrySet()) {
                LudumDare.font.setColor(i == currentMenuItem ? Color.ORANGE : Color.CYAN);
                Item item = Item.getItem(e.getKey());
                LudumDare.font.draw(batch, item.getDisplayName() + " x" + e.getValue(), -91, 50 - i * LudumDare.font.getLineHeight());
                i++;
            }
            LudumDare.font.setColor(Color.BLACK);
            LudumDare.font.draw(batch, "Press Z to use", -90, -50);
            LudumDare.font.setColor(Color.GREEN);
            LudumDare.font.draw(batch, "Press Z to use", -91, -49);
            
            batch.end();
        } else {
            font.setColor(Color.BLACK);
            font.setScale(0.7f);
            font.draw(batch, target.getName(), -115, 75);
            font.draw(batch, player.beast.getName(), 18, 0f);
            font.setScale(1);

            if (menu == 0) {
                font.setColor(currentMenuItem == 0 ? Color.ORANGE : Color.BLACK);
                font.draw(batch, "FIGHT", 22, -35);

                font.setColor(currentMenuItem == 1 ? Color.ORANGE : Color.BLACK);
                font.draw(batch, "BAG", 82, -35);

                font.setColor(currentMenuItem == 2 ? Color.ORANGE : Color.BLACK);
                font.draw(batch, "RUN", 22, -55);
            } else if (menu == 1) {
                String[] abStrings = player.beast.getAbillities();

                font.setColor(currentMenuItem == 0 ? Color.ORANGE : Color.BLACK);
                font.draw(batch, abStrings[0], -115, -35);

                font.setColor(currentMenuItem == 1 ? Color.ORANGE : Color.BLACK);
                font.draw(batch, abStrings[1], -45, -35);

                font.setColor(currentMenuItem == 2 ? Color.ORANGE : Color.BLACK);
                font.draw(batch, abStrings[2], -115, -55);

                font.setColor(currentMenuItem == 3 ? Color.ORANGE : Color.BLACK);
                font.draw(batch, abStrings[3], -45, -55);
            }

            batch.draw(target.getFrontRegion(), 20, 5);
            batch.draw(player.beast.getBackRegion(), -80, -32);
            
            batch.end();
            renderer.setProjectionMatrix(camera.combined);
            renderer.begin(ShapeType.Filled);
            renderer.setColor(Color.GREEN.cpy().lerp(Color.RED, 1f - ((float) target.getHealth() / (float) target.getMaxHealth())));
            renderer.rect(-115, 51, 102f * ((float) target.getHealth() / (float) target.getMaxHealth()), 10);
            renderer.setColor(Color.GREEN.cpy().lerp(Color.RED, 1f - ((float) player.beast.getHealth() / (float) player.beast.getMaxHealth())));
            renderer.rect(17, -23, 102f * ((float) player.beast.getHealth() / (float) player.beast.getMaxHealth()), 10);

            renderer.setColor(Color.BLUE.cpy().lerp(Color.CYAN, 1f - ((float) player.beast.getExp() / (float) player.beast.getNeededExp())));
            renderer.rect(17, -23, 102f * ((float) player.beast.getExp() / (float) player.beast.getNeededExp()), 2);
            renderer.end();

            if (messageBox != null) {
                if (messageBox.render()) {
                    messageBox.dispose();
                    messageBox = null;
                    delay = 15;
                }
            }
        }
        return false;
    }

    @Override
    public void dispose() {
        music.stop();
        music.dispose();
        renderer.dispose();
        batch.dispose();
        click.dispose();
    }

}
