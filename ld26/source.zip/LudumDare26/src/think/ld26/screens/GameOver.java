package think.ld26.screens;

import think.ld26.entity.Player;

public class GameOver extends Screen {

    public GameOver(Player player, boolean win) {
        
    }

    @Override
    public boolean render() {
        return false;
    }

    @Override
    public void dispose() {

    }

}
