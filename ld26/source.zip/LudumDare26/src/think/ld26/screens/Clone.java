package think.ld26.screens;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

import think.ld26.combat.Beast;

public class Clone extends Beast {

    private String name;
    
    public Clone(String name) {
        super(1);
        this.name = name;
    }

    @Override
    public TextureRegion getBackRegion() {
        return new TextureRegion(texture, 0,0,0,0);
    }

    @Override
    public TextureRegion getFrontRegion() {
        return new TextureRegion(texture, 0,0,0,0);
    }

    @Override
    public void levelUp() {

    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String[] getAbillities() {
        return null;
    }

    @Override
    public String doAbillity(Beast target, int a) {
        return null;
    }

}
