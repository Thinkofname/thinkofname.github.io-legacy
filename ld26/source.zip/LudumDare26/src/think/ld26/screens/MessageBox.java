package think.ld26.screens;

import think.ld26.LudumDare;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class MessageBox extends Screen {

    private String message;
    private SpriteBatch batch = new SpriteBatch();
    private Camera camera = new OrthographicCamera(240, 160);

    private static Texture chatBox;
    private static TextureRegion region;
    private float position = 0;
    private boolean extendPause = false;
    private int skipLines = 0;

    public MessageBox(String message) {
        this.message = message;
        if (chatBox == null) {
            chatBox = new Texture(Gdx.files.internal("data/sprites/chatbox.png"));
            chatBox.setFilter(TextureFilter.Nearest, TextureFilter.Nearest);
            region = new TextureRegion(chatBox, 0, 0, 240, 48);
        }
    }

    @Override
    public boolean render() {
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(region, -120, -160 + 80);
        BitmapFont font = LudumDare.font;
        float currentPos = 0;
        float currentY = 0;
        int lines = 0;
        font.setColor(Color.BLACK);
        int count = 0;
        loop: for (char c : message.toCharArray()) {
            count++;
            if (count > position)
                break;
            switch (c) {
            case '~':
                font.setColor(Color.CYAN);
                break;
            case '^':
                font.setColor(Color.RED);
                break;
            case '`':
                font.setColor(Color.YELLOW);
                break;
            case '|':
                font.setColor(Color.BLACK);
                break;
            default:
                String s = Character.toString(c);
                if (currentPos + font.getBounds(s).width > 230 && c != ' ') {
                    currentPos = 0;
                    if (lines >= skipLines) {
                        currentY += font.getLineHeight();
                    }
                    lines++;
                    if (lines >= 2 + skipLines) {
                        extendPause = true;
                        position += 0.1;
                        break loop;
                    }
                }
                if (c == '@')
                    break;
                if (lines >= skipLines) {
                    font.draw(batch, s, -115 + currentPos, -((160 - 48 - 5) - 70) - currentY);
                }
                currentPos += font.getBounds(s).width;
                break;
            }
        }
        batch.end();
        if (extendPause && Math.abs(position - (int) position) > 0.08) {
            position += Gdx.input.isKeyPressed(Input.Keys.Z) ? 0.005 : 0.001;
        } else {
            position += Gdx.input.isKeyPressed(Input.Keys.Z) ? 0.4 : 0.2;
            if (extendPause)
                skipLines += 2;
            extendPause = false;
        }

        if (count == message.length() && Gdx.input.isKeyPressed(Input.Keys.Z)) {
            return true;
        }
        return false;
    }

    @Override
    public void dispose() {
        batch.dispose();
    }

}
