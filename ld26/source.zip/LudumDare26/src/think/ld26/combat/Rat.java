package think.ld26.combat;

import java.util.Random;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

import think.ld26.LudumDare;

public class Rat extends Beast {
    
    private final static String[] abillities = {
        "Claw",
        "Bite",
        "Scare",
        "Stare"
    }; 

    public Rat(int level) {
        super(level);
        Random random = new Random();
        attack = 3 + (int)(0.5f * (float)level) + random.nextInt(3);
        defence = 3 + (int)(0.5f * (float)level) + random.nextInt(3);
        speed = 3 + (int)(0.5f * (float)level) + random.nextInt(3);
        bravery = 3 + (int)(0.5f * (float)level) + random.nextInt(3);
        maxHealth = 15 * (int)(2.5f * (float)level) + random.nextInt(8);
        health = maxHealth;
    }
    
    @Override
    public String getName() {
        return "Rat";
    }

    @Override
    public void levelUp() {
        attack += 1;
        defence += 1;
        speed += 1;
        bravery += 1;
        maxHealth += 2;
        health = maxHealth;
    }

    @Override
    public String[] getAbillities() {
        return abillities;
    }

    @Override
    public String doAbillity(Beast target, int a) {
        Random random = new Random();
        switch(a) {
        case 0:
            int damage = attack - target.defence + (random.nextInt(speed) - speed / 2);
            if (damage <=0) damage = 1;
            target.health -= damage;
            LudumDare.damage += damage;
            return "`" + getName() + "| clawed `" + target.getName() + "| for ^" + damage + "| damage";
        case 1:
            int damage2 = attack / 2 - random.nextInt(speed/2);
            if (damage2 <=0) damage = 1;
            target.health -= damage2;
            LudumDare.damage += damage2;
            return "`" + getName() + "| bite `" + target.getName() + "| for ^" + damage2 + "| damage";      
        case 2:
            int bDamage = bravery - target.bravery + (random.nextInt(speed / 4));
            target.bravery -= bDamage;
            if (bDamage < 0) {
                return "`" + getName() + "|'s attempt to scare `" + target.getName() + "| increase their bravery by ^" + (-bDamage);
            }
            return "`" + getName() + "| scared `" + target.getName() + "| reducing their bravery by ^" + bDamage;
        case 3:
            int bDamage2 = Math.abs(bravery) / 4;
            target.bravery -= bDamage2;
            if (bDamage2 <= 0) {
                return "`" + getName() + "| failed to scare `" + target.getName();
            }
            return "`" + getName() + "| scared `" + target.getName() + "| reducing their bravery by ^" + bDamage2;
        }
        return "Ze move... it did nothing";
    }

    private static TextureRegion front;
    private static TextureRegion back;
    
    @Override
    public TextureRegion getBackRegion() {
        if (back == null) {
            back = new TextureRegion(texture, 0, 0, 64, 64);
        }
        return back;
    }

    @Override
    public TextureRegion getFrontRegion() {
        if (front == null) {
            front = new TextureRegion(texture, 64, 0, 64, 64);
        }
        return front;
    }

}
