package think.ld26.combat;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public abstract class Beast {
    
    public int level;
    
    public int attack = 3;
    public int defence = 3;
    public int speed = 3;
    public int bravery = 3;
    public int maxHealth = 15;
    public int health = 15;
    public int exp = 0;
    
    protected static Texture texture;
    
    public Beast(int level) {
        this.level = level;
        if (texture == null) {
            texture = new Texture(Gdx.files.internal("data/sprites/rat.png"));
        }
    }
    
    public abstract TextureRegion getBackRegion();
    public abstract TextureRegion getFrontRegion();
    
    public abstract void levelUp();
    
    public abstract String getName();
    
    public abstract String[] getAbillities();
    
    public abstract String doAbillity(Beast target, int a);
    
    public int getHealth() {
        return health;
    }
    
    public int getMaxHealth() {
        return maxHealth;
    }
    
    public int getExp() {
        return exp;
    }
    
    public int getNeededExp() {
        return (int) Math.pow(2, ((float)(level+3) / 0.5f));
    }
}
