package think.ld26;

import think.ld26.entity.Player;
import think.ld26.map.Map;
import think.ld26.screens.MessageBox;
import think.ld26.screens.Screen;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.FPSLogger;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;

public class LudumDare implements ApplicationListener {
    private OrthographicCamera camera;
    private Map map;
    private FPSLogger fps = new FPSLogger();
    private static Screen screen = null;

    public static BitmapFont font;

    public static int damage = 0;
    
    @Override
    public void create() {
        camera = new OrthographicCamera(240, 160);
        map = new Map("testroom", this);
        Player player = new Player(map, map.getSpawnX() * 16, map.getSpawnY() * 16);
        map.setPlayer(player);
        map.addEntity(player);

        font = new BitmapFont(Gdx.files.internal("data/font.fnt"), false);
        
        display(new MessageBox("Urggh.@@@@@@.@@@@@@.@@@@@@@@@@ What happened?                  I should continue to the city. @@@(Z to continue)"));
    }

    @Override
    public void dispose() {
        map.dispose();
        font.dispose();
    }

    public static void display(Screen screen) {
        if (LudumDare.screen != null)
            LudumDare.screen.dispose();
        LudumDare.screen = screen;
    }

    @Override
    public void render() {
        fps.log();
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);

        if (screen == null) {
            map.tick();
        }
        map.draw(camera);
        if (screen != null) {
            if (screen.render()) {
                screen.dispose();
                screen = null;
            }
        }
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }
}
