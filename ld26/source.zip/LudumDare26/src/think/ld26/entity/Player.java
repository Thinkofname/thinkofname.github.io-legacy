package think.ld26.entity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

import think.ld26.combat.Beast;
import think.ld26.combat.Rat;
import think.ld26.items.Item;
import think.ld26.map.Map;
import think.ld26.screens.Battle;
import think.ld26.screens.Menu;
import think.ld26.screens.MessageBox;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.MapProperties;

public class Player extends EntityGrid {

    private static Texture texture;
    private static TextureRegion[] playerIdle = new TextureRegion[4];
    private static TextureRegion[][] playerWalk = new TextureRegion[4][4];
    private Sprite sprite;
    private float aniFrame = 0;

    private HashSet<Long> used = new HashSet<Long>();
    
    private int delay = 10;

    public HashMap<String, Integer> inventory = new HashMap<String, Integer>();
    public Beast beast = new Rat(2);

    public Player(Map map, int x, int y) {
        super(map, x, y);
        setSpeed((1f/16f)*8f);
        if (texture == null) {
            texture = new Texture(Gdx.files.internal("data/sprites/player.png"));
            texture.setFilter(TextureFilter.Nearest, TextureFilter.Nearest);

            // Idle textures
            playerIdle[0] = new TextureRegion(texture, 0, 0, 16, 16); // Up
            playerIdle[1] = new TextureRegion(texture, 0, 16, 16, 16); // Down
            playerIdle[2] = new TextureRegion(texture, 0, 32, 16, 16); // Left
            playerIdle[3] = new TextureRegion(texture, 0, 48, 16, 16); // Left

            // Walking Textures
            // Down
            playerWalk[0][0] = new TextureRegion(texture, 0, 0, 16, 16);
            playerWalk[0][1] = new TextureRegion(texture, 16, 0, 16, 16);
            playerWalk[0][2] = new TextureRegion(texture, 32, 0, 16, 16);
            playerWalk[0][3] = new TextureRegion(texture, 48, 0, 16, 16);
            // Up
            playerWalk[1][0] = new TextureRegion(texture, 0, 16, 16, 16);
            playerWalk[1][1] = new TextureRegion(texture, 16, 16, 16, 16);
            playerWalk[1][2] = new TextureRegion(texture, 32, 16, 16, 16);
            playerWalk[1][3] = new TextureRegion(texture, 48, 16, 16, 16);
            // Left
            playerWalk[2][0] = new TextureRegion(texture, 0, 32, 16, 16);
            playerWalk[2][1] = new TextureRegion(texture, 16, 32, 16, 16);
            playerWalk[2][2] = new TextureRegion(texture, 32, 32, 16, 16);
            playerWalk[2][3] = new TextureRegion(texture, 48, 32, 16, 16);
            // Left
            playerWalk[3][0] = new TextureRegion(texture, 0, 48, 16, 16);
            playerWalk[3][1] = new TextureRegion(texture, 16, 48, 16, 16);
            playerWalk[3][2] = new TextureRegion(texture, 32, 48, 16, 16);
            playerWalk[3][3] = new TextureRegion(texture, 48, 48, 16, 16);
        }
        sprite = new Sprite(playerIdle[0]);
    }

    @Override
    public void move(int x, int y) {
        int tx = x >> 4;
        int ty = y >> 4;
        if (!map.isSolid(tx, ty)) {
            super.move(x, y);
        } else {
            int direction = getY() > y ? 1 : 0;
            direction = getX() < x ? 3 : getX() != x ? 2 : direction;
            setDirection(direction);
        }
    }

    public void use(int x, int y) {
        long key = ((long) x) | ((long) (y) << 32);
        if (used.contains(key))
            return;
        MapProperties props = map.getProps(x, y);
        if (props != null && props.containsKey("item")) {
            if (inventory.size() >= 4) {
                map.display(new MessageBox("You can't carry any more items"));
                return;
            }
            used.add(key);
            String itemName = props.get("item", String.class);
            Item item = Item.getItem(itemName);
            int count = inventory.containsKey(itemName) ? inventory.get(itemName) : 0;
            count++;
            inventory.put(itemName, count);
            map.display(new MessageBox("You picked up a ~" + item.getDisplayName() + "|!     @@(Press X to open the menu)"));
        }
    }

    private boolean moving = false;
    private Random random = new Random();
    
    @Override
    public void tick() {
        delay--;
        if (!moving && !canMove()) {
            moving = true;
        } else if (moving && canMove()) {
            moving = false;
            if (random.nextInt(50) == 0) {
                map.display(new Battle(this, new Rat(1)));
            }
        }
        if (canMove()) {
            if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.Z)) {
                delay = 15;
                switch (getDirection()) {
                case 0: // Down
                    use(getX() >> 4, (getY() >> 4) + 1);
                    break;
                case 1:// Up
                    use(getX() >> 4, (getY() >> 4) - 1);
                    break;
                case 2:// Left
                    use((getX() >> 4) - 1, getY() >> 4);
                    break;
                case 3:// Right
                    use((getX() >> 4) + 1, getY() >> 4);
                    break;
                }
            } else if (delay <= 0 && Gdx.input.isKeyPressed(Input.Keys.X)) {
                delay = 15;
                map.display(new Menu(this));
            } else {
                if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
                    move(getX(), getY() - 16);
                }
                if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
                    move(getX(), getY() + 16);
                }
                if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
                    move(getX() - 16, getY());
                }
                if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
                    move(getX() + 16, getY());
                }
            }
        }
        update();
        if (canMove()) {
            sprite.setRegion(playerIdle[getDirection()]);
        } else {
            if (aniFrame >= playerWalk[getDirection()].length) {
                aniFrame = 0;
            }
            sprite.setRegion(playerWalk[getDirection()][(int) aniFrame]);
            aniFrame += 0.2;
        }
    }

    @Override
    public void draw(SpriteBatch batch) {
        shadow.setPosition(getDrawX(), getDrawY() - 2);
        shadow.draw(batch);
        sprite.setPosition(getDrawX(), getDrawY());
        sprite.draw(batch);
    }

}
