package think.ld26.entity;

import think.ld26.map.Map;

public abstract class EntityGrid extends Entity {
    
    private float x, y;
    private int gotoX, gotoY;
    
    private float drawX = 0, drawY = 0;
    
    private float speed = 0.5f;
    private int direction = 0;
    
    public EntityGrid(Map map, int x, int y) {
        super(map);
        this.x = x;
        this.y = y;
        gotoX = x;
        gotoY = y;
        calculateDrawCoords();
    }
    
    public void move(int x, int y) {
        gotoX = x;
        gotoY = y;
    }
    
    public boolean canMove() {
        return x == gotoX && y == gotoY;
    }
    
    protected void update() {
        if (x != gotoX || y != gotoY) {
            direction = y > gotoY ? 1 : 0;
            direction = x < gotoX ? 3 : x != gotoX ? 2 : direction;
            
            x += Math.signum(gotoX - x) * speed;
            y += Math.signum(gotoY - y) * speed;
            calculateDrawCoords();            
        }
    }
    
    private void calculateDrawCoords() {
        drawX = x;
        drawY = -y;
    }
    
    protected float getDrawX() {
        return drawX;
    }
    
    protected float getDrawY() {
        return drawY;
    }
    
    public int getX() {
        return (int) x;
    }
    
    public int getY() {
        return (int) y;
    }
    
    public float getXFloat() {
        return x;
    }
    
    public float getYFloat() {
        return y;
    }
    
    public float getSpeed() {
        return speed;
    }
    
    public void setSpeed(float speed) {
        this.speed = speed;
    }
    
    public int getDirection() {
        return direction;
    }
    
    public void setDirection(int dir) {
        direction = dir;
    }
}
