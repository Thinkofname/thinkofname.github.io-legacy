package think.ld26.entity;

import think.ld26.map.Map;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public abstract class Entity {
    
    protected Map map;
    
    private static Texture texture;
    private static TextureRegion region;
    protected Sprite shadow;
    
    public Entity(Map map) {
        this.map = map;
        if (texture == null) {
            texture = new Texture(Gdx.files.internal("data/sprites/shadow.png"));
            texture.setFilter(TextureFilter.Nearest, TextureFilter.Nearest);
            region = new TextureRegion(texture, 0, 0, 16, 16);;
        }
        shadow = new Sprite(region);
    }
    
    public abstract void tick();
    
    public abstract void draw(SpriteBatch batch);
}
