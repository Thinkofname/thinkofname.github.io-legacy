package think.ld26.map;

import think.ld26.LudumDare;
import think.ld26.entity.Entity;
import think.ld26.entity.Player;
import think.ld26.screens.Screen;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.utils.Array;

public class Map {
    
    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;
    private int height;
    private int width;
    private int horzTiles;
    private int vertTiles;
    
    private int []background = new int[]{0};
    private int []foreground = new int[]{1};
    
    private Array<Entity> entities = new Array<Entity>();
    private Player player;
    
    private SpriteBatch batch;
    private LudumDare ludumDare;
    
    public Map(String level, LudumDare ludumDare) {
        this.ludumDare = ludumDare;
        map = new TmxMapLoader().load("data/maps/" + level + ".tmx");
        renderer = new OrthogonalTiledMapRenderer(map);
        vertTiles = map.getProperties().get("height", int.class);
        horzTiles = map.getProperties().get("width", int.class);
        height = vertTiles * map.getProperties().get("tileheight", int.class);
        width = horzTiles * map.getProperties().get("tilewidth", int.class);
        batch = new SpriteBatch();
    }
    
    public MapProperties getProps(int x, int y) {
        y = vertTiles - y - 1;
        if (x < 0 || x >= horzTiles || y < 0 || y >= vertTiles) {
            return null;
        }
        MapLayer layer = map.getLayers().get("Objects");
        MapObjects objects = layer.getObjects();
        for (int i = 0; i < objects.getCount(); i++) {
            RectangleMapObject obj = (RectangleMapObject) objects.get(i);
            if (obj.getRectangle().contains(x << 4, y << 4)) {
                return obj.getProperties();
            }
        }
        return null;
    }
    
    public void display(Screen screen) {
        LudumDare.display(screen);
    }
    
    public void setPlayer(Player player) {
        this.player = player;
    }
    
    public void addEntity(Entity e) {
        entities.add(e);
    }
    
    public void tick() {
        for (Entity entity : entities) {
            entity.tick();
        }
    }
    
    public void draw(OrthographicCamera camera) {
        camera.position.set(player.getX(), -player.getY() + getHeight() - 16, 0);
        camera.update(true);
        
        renderer.setView(camera);
        renderer.render(background);       

        camera.translate(0, -getHeight() + 16);
        camera.update(true);
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        for (Entity entity : entities) {
            entity.draw(batch);
        }
        batch.end();

        camera.position.set(player.getX(), -player.getY() + getHeight() - 16, 0);
        camera.update(true);
        renderer.setView(camera);
        renderer.render(foreground); 
        camera.position.set(0,0,0);
        camera.update(true);
        batch.setProjectionMatrix(camera.combined);
        batch.begin();  
        LudumDare.font.setScale(0.7f);
        LudumDare.font.setColor(Color.BLACK);
        LudumDare.font.draw(batch, "Damage: " + LudumDare.damage, -114, 74);
        LudumDare.font.setColor(Color.WHITE);
        LudumDare.font.draw(batch, "Damage: " + LudumDare.damage, -115, 75);
        LudumDare.font.setScale(1f);
        batch.end();
    }
    
    
    public boolean isSolid(int x, int y) {
        y = vertTiles - y - 1;
        if (x < 0 || x >= horzTiles || y < 0 || y >= vertTiles) {
            return true;
        }
        TiledMapTileLayer layer = (TiledMapTileLayer) map.getLayers().get("Background");     
        String solid = layer.getCell(x, y).getTile().getProperties().get("solid", String.class);
        return solid != null ? solid.equalsIgnoreCase("true") : false;
    }
    
    public int getSpawnX() {
        return Integer.parseInt(map.getProperties().get("spawnX", String.class));
    }
    
    public int getSpawnY() {
        return Integer.parseInt(map.getProperties().get("spawnY", String.class));
    }
    
    public int getHeight() {
        return height;
    }
    
    public int getWidth() {
        return width;
    }
    
    public void dispose() {
        map.dispose();
        renderer.dispose();
        batch.dispose();
    }
}
