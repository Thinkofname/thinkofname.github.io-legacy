package think.ld26.items;

import java.util.HashMap;

import think.ld26.combat.Beast;

public abstract class Item {

    private static HashMap<String, Item> items = new HashMap<String, Item>();
    
    static {
        items.put("healthPotion", new HealthPotion());
        items.put("cage", new Cage());
    }
    
    public static Item getItem(String name) {
        return items.get(name);
    }
    
    
    public abstract String getDisplayName();


    public abstract String use(Beast player, Beast target);
}
