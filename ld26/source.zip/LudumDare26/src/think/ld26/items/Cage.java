package think.ld26.items;

import java.util.Random;

import think.ld26.combat.Beast;

public class Cage extends Item {

    @Override
    public String getDisplayName() {
        return "Cage";
    }

    @Override
    public String use(Beast player, Beast target) {
        Random random = new Random();
        if (random.nextDouble() < 0.2) {
            
            return "You caught `" + target.getName();
        }
        return "You failed to catch `" + target.getName();
    }

}
