package think.ld26.items;

import think.ld26.combat.Beast;

public class HealthPotion extends Item {

    @Override
    public String getDisplayName() {
        return "Health Potion";
    }

    @Override
    public String use(Beast player, Beast target) {
        player.health += 10;
        if (player.health > player.maxHealth) player.health = player.maxHealth;
        return "`" + player.getName() + "| was healed by ^10";
    }

}
