package think.ld26.client;

import think.ld26.LudumDare;
import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.backends.gwt.GwtApplication;
import com.badlogic.gdx.backends.gwt.GwtApplicationConfiguration;

public class GwtLauncher extends GwtApplication {
	@Override
	public GwtApplicationConfiguration getConfig () {
		GwtApplicationConfiguration cfg = new GwtApplicationConfiguration(240*3, 160*3);
		cfg.antialiasing = true;
		return cfg;
	}

	@Override
	public ApplicationListener getApplicationListener () {
		return new LudumDare();
	}
}